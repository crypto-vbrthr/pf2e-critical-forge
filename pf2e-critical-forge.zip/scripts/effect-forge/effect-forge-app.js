import { MODULE_ID, SETTINGS } from "../constants.js";
import {
  initializeConditionCatalog,
  isValuedCondition
} from "../effect-engine/catalogs/condition-catalog.js";
import { getDamageTypeGroups } from "../effect-engine/catalogs/damage-type-catalog.js";
import { getResistanceTypeGroups } from "../effect-engine/catalogs/resistance-type-catalog.js";
import { getWeaknessTypeGroups } from "../effect-engine/catalogs/weakness-type-catalog.js";
import { getImmunityTypeGroups } from "../effect-engine/catalogs/immunity-type-catalog.js";
import { getBaseSpeedTypeGroups, getMovementTypeGroups } from "../effect-engine/catalogs/movement-type-catalog.js";
import { captureScrollState, restoreScrollState } from "./view-state.js";
import {
  attachComponentUiState,
  createEditorSnapshot,
  duplicateComponent,
  moveComponent,
  normalizeWindowState,
  stripComponentUiState,
  toggleComponentCollapsed
} from "./gui-state.js";
import { getEffectItemDragData, resolveDroppedEffectItem } from "./effect-item-drop.js";
import {
  EffectTransferError,
  buildEffectExportFilename,
  downloadEffectExport,
  effectDescriptionToPlainText,
  readEffectImportFile
} from "./effect-transfer.js";

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

const FALLBACK_CONDITIONS = [
  "blinded", "clumsy", "concealed", "confused", "controlled", "dazzled",
  "deafened", "doomed", "drained", "dying", "encumbered", "enfeebled",
  "fascinated", "fatigued", "fleeing", "frightened", "grabbed", "hidden",
  "immobilized", "invisible", "off-guard", "paralyzed",
  "prone", "quickened", "restrained", "sickened", "slowed", "stunned",
  "stupefied", "unconscious", "undetected", "wounded"
];


const MODIFIER_TYPE_DEFINITIONS = [
  ["status", "PF2E_CRITICAL_FORGE.EffectForge.ModifierTypes.Status"],
  ["circumstance", "PF2E_CRITICAL_FORGE.EffectForge.ModifierTypes.Circumstance"],
  ["item", "PF2E_CRITICAL_FORGE.EffectForge.ModifierTypes.Item"],
  ["untyped", "PF2E_CRITICAL_FORGE.EffectForge.ModifierTypes.Untyped"]
];

const VALIDATION_GROUPS = [
  ["error", "PF2E_CRITICAL_FORGE.EffectForge.Validation.Errors", "fa-circle-xmark"],
  ["warning", "PF2E_CRITICAL_FORGE.EffectForge.Validation.Warnings", "fa-triangle-exclamation"],
  ["hint", "PF2E_CRITICAL_FORGE.EffectForge.Validation.Hints", "fa-circle-info"],
  ["info", "PF2E_CRITICAL_FORGE.EffectForge.Validation.Information", "fa-circle-info"]
];

const TRANSFER_ERROR_KEYS = Object.freeze({
  IMPORT_EMPTY: "Empty",
  IMPORT_JSON_INVALID: "InvalidJson",
  IMPORT_DOCUMENT_OBJECT: "ObjectRequired",
  IMPORT_FORMAT_UNSUPPORTED: "UnsupportedFormat",
  IMPORT_FORMAT_VERSION_UNSUPPORTED: "UnsupportedFormatVersion",
  IMPORT_DEFINITION_MISSING: "MissingDefinition",
  IMPORT_SCHEMA_VERSION_UNSUPPORTED: "UnsupportedSchemaVersion",
  IMPORT_UNMANAGED_RULES_INVALID: "InvalidUnmanagedRules",
  IMPORT_FILE_INVALID: "InvalidFile",
  IMPORT_FILE_TOO_LARGE: "FileTooLarge",
  IMPORT_VALIDATION_FAILED: "ValidationFailed",
  EXPORT_VALIDATION_FAILED: "ExportValidationFailed",
  CLIPBOARD_UNAVAILABLE: "ClipboardUnavailable"
});

function createInitialState({ example = true } = {}) {
  return {
    effectId: example ? "example.shaken-nerves" : `pf2e-critical-forge.custom.${foundry.utils.randomID()}`,
    effectName: example
      ? game.i18n.localize("PF2E_CRITICAL_FORGE.Examples.ShakenNerves.Name")
      : "",
    description: example
      ? game.i18n.localize("PF2E_CRITICAL_FORGE.Examples.ShakenNerves.PlainDescription")
      : "",
    img: example ? "icons/svg/terror.svg" : "icons/svg/aura.svg",
    durationValue: example ? 2 : 1,
    durationUnit: "rounds",
    durationExpiry: "turn-end",
    components: (example
      ? [
          { type: "condition", slug: "frightened", value: 2 },
          { type: "modifier", selector: "will", value: -1, modifierType: "circumstance" }
        ]
      : []).map((component) => attachComponentUiState(component))
  };
}

function listWorldEffects() {
  const collection = game.items;
  if (!collection) return [];
  const items = typeof collection.filter === "function"
    ? collection.filter((item) => item.type === "effect")
    : [...collection].filter((item) => item.type === "effect");
  return [...items].sort((a, b) => String(a.name).localeCompare(String(b.name), game.i18n.lang));
}

export class EffectForgeApp extends HandlebarsApplicationMixin(ApplicationV2) {
  validationReport = null;
  definitionPreview = null;
  compiledPreview = null;
  componentMenuOpen = false;
  preservedScrollState = new Map();
  sourceItem = null;
  selectedItemId = "";
  unmanagedRules = [];
  itemReadWarnings = [];
  definitionApplication = {};
  definitionMetadata = {};
  isDirty = false;
  cleanSnapshot = "";
  migrationReport = null;
  resizeObserver = null;
  windowStateTimer = null;
  controlTokenHook = null;
  allowCloseWithoutPrompt = false;
  externalCommit = null;
  externalMode = false;
  externalCloseOnCommit = true;

  state = null;

  static DEFAULT_OPTIONS = {
    id: "pf2e-critical-forge-effect-forge",
    classes: ["pf2e-critical-forge", "effect-forge"],
    tag: "form",
    window: {
      title: "PF2E_CRITICAL_FORGE.EffectForge.WindowTitle",
      icon: "fa-solid fa-hammer",
      resizable: true
    },
    position: {
      width: 1220,
      height: 820
    },
    actions: {
      loadSelectedItem: EffectForgeApp.#loadSelectedItem,
      importJsonFile: EffectForgeApp.#importJsonFile,
      importClipboard: EffectForgeApp.#importClipboard,
      exportJson: EffectForgeApp.#exportJson,
      copyExport: EffectForgeApp.#copyExport,
      newEffect: EffectForgeApp.#newEffect,
      toggleComponentMenu: EffectForgeApp.#toggleComponentMenu,
      addCondition: EffectForgeApp.#addCondition,
      addModifier: EffectForgeApp.#addModifier,
      addPersistentDamage: EffectForgeApp.#addPersistentDamage,
      addResistance: EffectForgeApp.#addResistance,
      addWeakness: EffectForgeApp.#addWeakness,
      addImmunity: EffectForgeApp.#addImmunity,
      addFastHealing: EffectForgeApp.#addFastHealing,
      addRegeneration: EffectForgeApp.#addRegeneration,
      addTemporaryHitPoints: EffectForgeApp.#addTemporaryHitPoints,
      addMovement: EffectForgeApp.#addMovement,
      addBaseSpeed: EffectForgeApp.#addBaseSpeed,
      removeComponent: EffectForgeApp.#removeComponent,
      duplicateComponent: EffectForgeApp.#duplicateComponent,
      moveComponentUp: EffectForgeApp.#moveComponentUp,
      moveComponentDown: EffectForgeApp.#moveComponentDown,
      toggleComponentCollapsed: EffectForgeApp.#toggleComponentCollapsed,
      focusComponent: EffectForgeApp.#focusComponent,
      browseImage: EffectForgeApp.#browseImage,
      validateEffect: EffectForgeApp.#validateEffect,
      compileEffect: EffectForgeApp.#compileEffect,
      createItem: EffectForgeApp.#createItem,
      updateItem: EffectForgeApp.#updateItem,
      applySelected: EffectForgeApp.#applySelected,
      copyDefinition: EffectForgeApp.#copyDefinition,
      copyCompiled: EffectForgeApp.#copyCompiled,
      commitExternal: EffectForgeApp.#commitExternal,
      closeWindow: EffectForgeApp.#closeWindow
    }
  };

  static PARTS = {
    form: {
      template: `modules/${MODULE_ID}/templates/effect-forge/effect-forge-app.hbs`
    }
  };

  constructor(options = {}) {
    let savedPosition = {};
    try {
      savedPosition = normalizeWindowState(
        game.settings?.get?.(MODULE_ID, SETTINGS.EFFECT_FORGE_WINDOW_STATE) ?? {}
      );
    } catch {
      savedPosition = {};
    }

    super(foundry.utils.mergeObject(
      { position: savedPosition },
      options,
      { inplace: false }
    ));
    this.state = createInitialState();
    this.cleanSnapshot = this.#editorSnapshot();
    this.isDirty = false;
  }

  _onPosition(position) {
    super._onPosition(position);
    if (!this.state) return;
    globalThis.clearTimeout(this.windowStateTimer);
    this.windowStateTimer = globalThis.setTimeout(() => this.#persistWindowState(), 300);
  }

  #setStateFromDefinition(definition, { fallbackName = "", fallbackImage = "icons/svg/aura.svg" } = {}) {
    this.definitionApplication = foundry.utils.deepClone(definition.application ?? {});
    this.definitionMetadata = foundry.utils.deepClone(definition.metadata ?? {});
    this.state = {
      effectId: definition.id ?? `pf2e-critical-forge.custom.${foundry.utils.randomID()}`,
      effectName: definition.name ?? fallbackName,
      description: effectDescriptionToPlainText(definition.description ?? ""),
      img: definition.img ?? fallbackImage,
      durationValue: definition.duration?.unit === "unlimited" ? 1 : (definition.duration?.value ?? 1),
      durationUnit: definition.duration?.unit ?? "unlimited",
      durationExpiry: definition.duration?.expiry ?? "turn-end",
      components: foundry.utils.deepClone(definition.components ?? [])
        .map((component) => attachComponentUiState(component))
    };
  }

  async loadDefinition(definition, {
    render = true,
    fallbackName = "",
    fallbackImage = "icons/svg/aura.svg",
    onCommit = null,
    closeOnCommit = true
  } = {}) {
    this.sourceItem = null;
    this.selectedItemId = "";
    this.unmanagedRules = [];
    this.itemReadWarnings = [];
    this.migrationReport = null;
    this.externalCommit = typeof onCommit === "function" ? onCommit : null;
    this.externalMode = Boolean(this.externalCommit);
    this.externalCloseOnCommit = closeOnCommit !== false;
    this.#setStateFromDefinition(definition, { fallbackName, fallbackImage });
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markClean();
    if (render) await this.render({ force: true });
    return this;
  }

  async loadItem(item, { render = true } = {}) {
    const result = await this.constructor.#api().effects.readItem(item);
    const definition = result.definition;

    this.externalCommit = null;
    this.externalMode = false;
    this.sourceItem = item;
    this.selectedItemId = item.id ?? result.sourceItemId ?? "";
    this.unmanagedRules = foundry.utils.deepClone(result.unmanagedRules ?? []);
    this.itemReadWarnings = foundry.utils.deepClone(result.warnings ?? []);
    this.migrationReport = foundry.utils.deepClone(result.migration ?? null);
    this.#setStateFromDefinition(definition, {
      fallbackName: item.name ?? "",
      fallbackImage: item.img ?? "icons/svg/aura.svg"
    });

    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markClean();
    if (render) await this.render({ force: true });
    return result;
  }

  resetToNewEffect({ render = true } = {}) {
    this.externalCommit = null;
    this.externalMode = false;
    this.sourceItem = null;
    this.selectedItemId = "";
    this.unmanagedRules = [];
    this.itemReadWarnings = [];
    this.definitionApplication = {};
    this.definitionMetadata = {};
    this.migrationReport = null;
    this.state = createInitialState({ example: false });
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markClean();
    if (render) return this.render({ force: true });
    return this;
  }

  async _prepareContext() {
    const api = game.modules.get(MODULE_ID)?.api;
    await initializeConditionCatalog();
    await this.#ensurePreviewData();

    const worldEffects = listWorldEffects();
    const selectedItemId = this.selectedItemId || this.sourceItem?.id || "";

    return {
      apiReady: Boolean(api),
      apiVersion: api?.version ?? "—",
      schemaVersion: api?.schemaVersion ?? "—",
      state: this.state,
      externalMode: this.externalMode,
      editingItem: Boolean(this.sourceItem),
      sourceItemName: this.sourceItem?.name ?? "",
      sourceItemUuid: this.sourceItem?.uuid ?? "",
      unmanagedRuleCount: this.unmanagedRules.length,
      unmanagedRulesWarningText: game.i18n.format(
        "PF2E_CRITICAL_FORGE.EffectForge.UnmanagedRulesPreserved",
        { count: this.unmanagedRules.length }
      ),
      itemReadWarnings: this.itemReadWarnings,
      hasItemReadWarnings: this.unmanagedRules.length > 0,
      hasWorldEffects: worldEffects.length > 0,
      worldEffectOptions: worldEffects.map((item) => ({
        value: item.id,
        label: item.name,
        selected: item.id === selectedItemId
      })),
      descriptionLength: this.state.description.length,
      unlimitedDuration: this.state.durationUnit === "unlimited",
      componentMenuOpen: this.componentMenuOpen,
      components: this.state.components.map((component, index) =>
        this.#prepareComponent(component, index)
      ),
      isDirty: this.isDirty,
      dirtyStatusText: game.i18n.localize(
        this.isDirty
          ? "PF2E_CRITICAL_FORGE.EffectForge.UnsavedChanges"
          : "PF2E_CRITICAL_FORGE.EffectForge.AllChangesSaved"
      ),
      hasSelectedTokens: (globalThis.canvas?.tokens?.controlled?.length ?? 0) > 0,
      migrationReport: this.migrationReport,
      validationReport: this.validationReport,
      definitionPreview: this.definitionPreview,
      compiledPreview: this.compiledPreview
    };
  }

  _onRender(context, options) {
    super._onRender(context, options);

    const root = this.element;
    if (!(root instanceof HTMLElement)) return;

    const markDirty = (event) => {
      const target = event.target;
      if (target?.name === "selectedItemId") return;
      this.#markDirty();
    };
    root.addEventListener("input", markDirty);
    root.addEventListener("change", markDirty);

    const description = root.querySelector('textarea[name="description"]');
    const counter = root.querySelector("[data-description-counter]");
    description?.addEventListener("input", () => {
      if (counter) counter.textContent = `${description.value.length} / 1000`;
    });

    const unlimited = root.querySelector('input[name="unlimitedDuration"]');
    const durationControls = root.querySelectorAll("[data-duration-control]");
    const updateDurationState = () => {
      const disabled = Boolean(unlimited?.checked);
      for (const control of durationControls) control.disabled = disabled;
    };
    unlimited?.addEventListener("change", updateDurationState);
    updateDurationState();

    for (const card of root.querySelectorAll("[data-component-duration]")) {
      const override = card.querySelector("[data-component-duration-override]");
      const unlimitedComponent = card.querySelector("[data-component-duration-unlimited]");
      const controls = card.querySelectorAll("[data-component-duration-control]");

      const updateComponentDurationState = () => {
        const enabled = Boolean(override?.checked);
        const infinite = Boolean(unlimitedComponent?.checked);
        if (unlimitedComponent) unlimitedComponent.disabled = !enabled;
        for (const control of controls) control.disabled = !enabled || infinite;
        card.classList.toggle("duration-override-enabled", enabled);
      };

      override?.addEventListener("change", updateComponentDurationState);
      unlimitedComponent?.addEventListener("change", updateComponentDurationState);
      updateComponentDurationState();
    }

    const customValue = this.constructor.#api().selectors.customValue;
    for (const conditionChoice of root.querySelectorAll("[data-condition-choice]")) {
      const card = conditionChoice.closest(".effect-forge-component-card");
      const valueField = card?.querySelector("[data-condition-value-field]");
      const valueInput = valueField?.querySelector("input");

      const updateConditionValue = () => {
        const selected = conditionChoice.selectedOptions?.[0];
        const isValued = selected?.dataset.valued === "true";
        if (valueField) valueField.hidden = !isValued;
        if (valueInput) {
          valueInput.disabled = !isValued;
          if (isValued && valueInput.value === "") valueInput.value = "1";
          if (!isValued) valueInput.value = "";
        }
      };

      conditionChoice.addEventListener("change", updateConditionValue);
      updateConditionValue();
    }

    for (const selectorChoice of root.querySelectorAll("[data-selector-choice]")) {
      const card = selectorChoice.closest(".effect-forge-component-card");
      const customField = card?.querySelector("[data-custom-selector-field]");
      const customInput = customField?.querySelector("input");

      const updateCustomSelector = () => {
        const custom = selectorChoice.value === customValue;
        if (customField) customField.hidden = !custom;
        if (customInput) {
          customInput.disabled = !custom;
          customInput.required = custom;
        }
      };

      selectorChoice.addEventListener("change", updateCustomSelector);
      updateCustomSelector();
    }

    this.#activateEffectDropZone(root);
    this.#activateWindowStatePersistence(root);
    this.#activateTokenSelectionTracking();
    this.#updateDirtyIndicator();
    this.#updateTokenActionState();
    this.#restoreScrollPositions();
  }

  #editorSnapshot() {
    return createEditorSnapshot({ state: this.state, unmanagedRules: this.unmanagedRules });
  }

  #markClean() {
    this.cleanSnapshot = this.#editorSnapshot();
    this.isDirty = false;
    this.#updateDirtyIndicator();
  }

  #markDirty() {
    this.isDirty = true;
    this.#updateDirtyIndicator();
  }

  #refreshDirtyState() {
    this.isDirty = this.#editorSnapshot() !== this.cleanSnapshot;
    this.#updateDirtyIndicator();
  }

  #updateDirtyIndicator() {
    const root = this.element;
    if (!(root instanceof HTMLElement)) return;
    const indicator = root.querySelector("[data-dirty-indicator]");
    if (!(indicator instanceof HTMLElement)) return;
    indicator.classList.toggle("dirty", this.isDirty);
    indicator.classList.toggle("clean", !this.isDirty);
    const text = indicator.querySelector("[data-dirty-text]");
    if (text) {
      text.textContent = game.i18n.localize(
        this.isDirty
          ? "PF2E_CRITICAL_FORGE.EffectForge.UnsavedChanges"
          : "PF2E_CRITICAL_FORGE.EffectForge.AllChangesSaved"
      );
    }
  }

  async #confirmDiscardChanges() {
    if (!this.isDirty) return true;

    const title = game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.DiscardChangesTitle");
    const content = `<p>${game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.DiscardChangesPrompt")}</p>`;
    const DialogV2 = foundry.applications?.api?.DialogV2;
    if (DialogV2?.confirm) {
      return Boolean(await DialogV2.confirm({
        window: { title },
        content,
        modal: true,
        rejectClose: false
      }));
    }

    if (globalThis.Dialog?.confirm) {
      return new Promise((resolve) => {
        globalThis.Dialog.confirm({
          title,
          content,
          yes: () => resolve(true),
          no: () => resolve(false),
          close: () => resolve(false)
        });
      });
    }

    return globalThis.confirm?.(game.i18n.localize(
      "PF2E_CRITICAL_FORGE.EffectForge.DiscardChangesPrompt"
    )) ?? false;
  }


  #activateTokenSelectionTracking() {
    if (this.controlTokenHook != null || !globalThis.Hooks?.on) return;
    this.controlTokenHook = globalThis.Hooks.on("controlToken", () => {
      this.#updateTokenActionState();
    });
  }

  #updateTokenActionState() {
    const root = this.element;
    if (!(root instanceof HTMLElement)) return;
    const button = root.querySelector('[data-action="applySelected"]');
    if (!(button instanceof HTMLButtonElement)) return;

    const hasSelectedTokens = (globalThis.canvas?.tokens?.controlled?.length ?? 0) > 0;
    button.disabled = !hasSelectedTokens;
    button.title = game.i18n.localize(
      hasSelectedTokens
        ? "PF2E_CRITICAL_FORGE.EffectForge.ApplySelectedTooltip"
        : "PF2E_CRITICAL_FORGE.EffectForge.ApplySelectedDisabledTooltip"
    );
  }

  #activateWindowStatePersistence(root) {
    this.resizeObserver?.disconnect?.();
    this.resizeObserver = null;

    const queueSave = () => {
      globalThis.clearTimeout(this.windowStateTimer);
      this.windowStateTimer = globalThis.setTimeout(() => this.#persistWindowState(), 300);
    };

    if (typeof globalThis.ResizeObserver === "function") {
      this.resizeObserver = new globalThis.ResizeObserver(queueSave);
      this.resizeObserver.observe(root);
    }

    root.addEventListener("pointerup", queueSave);
  }

  async #persistWindowState() {
    try {
      const root = this.element;
      const rect = root instanceof HTMLElement ? root.getBoundingClientRect() : null;
      const position = this.position ?? {};
      const value = normalizeWindowState({
        width: position.width ?? rect?.width,
        height: position.height ?? rect?.height,
        left: position.left ?? rect?.left,
        top: position.top ?? rect?.top
      });
      await game.settings?.set?.(MODULE_ID, SETTINGS.EFFECT_FORGE_WINDOW_STATE, value);
    } catch (error) {
      console.debug(`${MODULE_ID} | Could not persist Effect Forge window state`, error);
    }
  }

  async close(options = {}) {
    if (!this.allowCloseWithoutPrompt && this.isDirty) {
      const confirmed = await this.#confirmDiscardChanges();
      if (!confirmed) return this;
    }

    this.allowCloseWithoutPrompt = false;
    globalThis.clearTimeout(this.windowStateTimer);
    await this.#persistWindowState();
    this.resizeObserver?.disconnect?.();
    if (this.controlTokenHook != null && globalThis.Hooks?.off) {
      globalThis.Hooks.off("controlToken", this.controlTokenHook);
      this.controlTokenHook = null;
    }
    return super.close(options);
  }

  #activateEffectDropZone(root) {
    const dropZone = root.querySelector("[data-effect-drop-zone]");
    if (!(dropZone instanceof HTMLElement)) return;

    let dragDepth = 0;
    const clearHighlight = () => {
      dragDepth = 0;
      dropZone.classList.remove("drag-active");
      dropZone.removeAttribute("aria-busy");
    };

    dropZone.addEventListener("dragenter", (event) => {
      event.preventDefault();
      dragDepth += 1;
      dropZone.classList.add("drag-active");
      dropZone.setAttribute("aria-busy", "true");
    });

    dropZone.addEventListener("dragover", (event) => {
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
    });

    dropZone.addEventListener("dragleave", (event) => {
      event.preventDefault();
      dragDepth = Math.max(0, dragDepth - 1);
      if (dragDepth === 0) clearHighlight();
    });

    dropZone.addEventListener("drop", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      clearHighlight();
      await this.#loadDroppedEffect(event);
    });
  }

  async #loadDroppedEffect(event) {
    try {
      const data = getEffectItemDragData(event);
      const result = await resolveDroppedEffectItem(data);

      if (result.status === "unsupported") {
        ui.notifications.warn(
          game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.DropUnsupportedDocument")
        );
        return;
      }

      if (result.status === "not-effect") {
        ui.notifications.warn(
          game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.DropOnlyEffectItems")
        );
        return;
      }

      if (result.status === "not-found") {
        ui.notifications.warn(
          game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.DropItemNotFound")
        );
        return;
      }

      if (!await this.#confirmDiscardChanges()) return;
      await this.loadItem(result.item, { render: false });
      this.preservedScrollState = new Map();
      await this.render({ force: true });
      ui.notifications.info(game.i18n.format(
        "PF2E_CRITICAL_FORGE.EffectForge.ItemLoaded",
        { name: result.item.name }
      ));
    } catch (error) {
      console.error(`${MODULE_ID} | Dropped effect Item could not be loaded`, error);
      ui.notifications.error(error.message);
    }
  }

  #captureScrollPositions() {
    const root = this.element;
    this.preservedScrollState = root instanceof HTMLElement
      ? captureScrollState(root)
      : new Map();
  }

  #restoreScrollPositions() {
    if (!(this.preservedScrollState instanceof Map) || this.preservedScrollState.size === 0) {
      return;
    }

    const state = this.preservedScrollState;
    this.preservedScrollState = new Map();

    const restore = () => {
      const root = this.element;
      if (root instanceof HTMLElement) restoreScrollState(root, state);
    };

    if (typeof globalThis.requestAnimationFrame === "function") {
      globalThis.requestAnimationFrame(restore);
    } else {
      globalThis.setTimeout(restore, 0);
    }
  }

  #renderPreservingScroll() {
    this.#captureScrollPositions();
    return this.render({ force: true });
  }

  static #api() {
    const api = game.modules.get(MODULE_ID)?.api;
    if (!api) throw new Error("Effect Engine API is unavailable.");
    return api;
  }

  #prepareComponent(component, index) {
    const componentValidation = this.#componentValidationStatus(index);
    const base = {
      ...component,
      index,
      number: index + 1,
      uiId: component._uiId,
      collapsed: Boolean(component._collapsed),
      canMoveUp: index > 0,
      canMoveDown: index < this.state.components.length - 1,
      summary: this.#componentSummary(component),
      validationStatus: componentValidation,
      hasValidationStatus: Boolean(componentValidation),
      isCondition: component.type === "condition",
      isModifier: component.type === "modifier",
      isPersistentDamage: component.type === "persistentDamage",
      isResistance: component.type === "resistance",
      isWeakness: component.type === "weakness",
      isImmunity: component.type === "immunity",
      isFastHealing: component.type === "fastHealing",
      isRegeneration: component.type === "regeneration",
      isTemporaryHitPoints: component.type === "temporaryHitPoints",
      isMovement: component.type === "movement",
      isBaseSpeed: component.type === "baseSpeed",
      hasDurationOverride: Boolean(component.duration),
      componentDurationValue: component.duration?.unit === "unlimited"
        ? 1
        : (component.duration?.value ?? 1),
      componentDurationUnit: component.duration?.unit ?? "rounds",
      componentDurationExpiry: component.duration?.expiry ?? "turn-end",
      componentUnlimitedDuration: component.duration?.unit === "unlimited"
    };

    if (base.isCondition) {
      base.isValuedCondition = isValuedCondition(component.slug);
      base.value = base.isValuedCondition ? (component.value ?? 1) : undefined;
      base.conditionOptions = this.#conditionOptions(component.slug);
    }

    if (base.isModifier) {
      const selectorApi = this.constructor.#api().selectors;
      base.selectorGroups = selectorApi.groups(component.selector);
      base.usesCustomSelector = !selectorApi.has(component.selector);
      base.customSelector = base.usesCustomSelector ? component.selector : "";
      base.modifierTypeOptions = MODIFIER_TYPE_DEFINITIONS.map(([value, key]) => ({
        value,
        label: game.i18n.localize(key),
        selected: component.modifierType === value
      }));
    }

    if (base.isPersistentDamage) {
      base.damageTypeGroups = getDamageTypeGroups(component.damageType);
      base.dc = component.dc ?? "";
    }

    if (base.isResistance) {
      base.resistanceTypeGroups = getResistanceTypeGroups(component.resistanceType);
    }

    if (base.isWeakness) {
      base.weaknessTypeGroups = getWeaknessTypeGroups(component.weaknessType);
    }

    if (base.isImmunity) {
      base.immunityTypeGroups = getImmunityTypeGroups(component.immunityType);
    }

    if (base.isRegeneration) {
      base.damageTypeGroups = getDamageTypeGroups(component.deactivatedBy ?? []);
    }

    if (base.isMovement) {
      base.movementTypeGroups = getMovementTypeGroups(component.movementType);
      base.modifierTypeOptions = MODIFIER_TYPE_DEFINITIONS.map(([value, key]) => ({
        value,
        label: game.i18n.localize(key),
        selected: component.modifierType === value
      }));
    }

    if (base.isBaseSpeed) {
      base.baseSpeedTypeGroups = getBaseSpeedTypeGroups(component.movementType);
    }

    return base;
  }

  #componentValidationStatus(index) {
    const issues = this.validationReport?.groups
      ?.flatMap((group) => group.issues ?? [])
      ?.filter((issue) => issue.componentIndex === index) ?? [];
    if (issues.length === 0) return null;

    const priority = ["error", "warning", "hint", "info"];
    const severity = priority.find((candidate) =>
      issues.some((issue) => issue.severity === candidate)
    ) ?? "info";
    const icons = {
      error: "fa-circle-xmark",
      warning: "fa-triangle-exclamation",
      hint: "fa-circle-info",
      info: "fa-circle-info"
    };
    return {
      severity,
      icon: icons[severity],
      count: issues.length,
      title: game.i18n.format("PF2E_CRITICAL_FORGE.EffectForge.ComponentIssueCount", {
        count: issues.length
      })
    };
  }

  #componentSummary(component) {
    const localize = (key) => game.i18n.localize(key);
    let summary;
    switch (component.type) {
      case "condition":
        summary = `${component.slug}${component.value == null ? "" : ` ${component.value}`}`;
        break;
      case "modifier":
        summary = `${component.value > 0 ? "+" : ""}${component.value} ${component.modifierType} · ${component.selector}`;
        break;
      case "persistentDamage":
        summary = `${component.formula} ${component.damageType}${component.dc ? ` · DC ${component.dc}` : ""}`;
        break;
      case "resistance":
        summary = `${component.resistanceType} ${component.value}`;
        break;
      case "weakness":
        summary = `${component.weaknessType} ${component.value}`;
        break;
      case "immunity":
        summary = String(component.immunityType ?? "");
        break;
      case "fastHealing":
        summary = `${localize("PF2E_CRITICAL_FORGE.EffectForge.FastHealing")} ${component.value}`;
        break;
      case "regeneration":
        summary = `${component.value} · ${(component.deactivatedBy ?? []).join(", ")}`;
        break;
      case "temporaryHitPoints":
        summary = String(component.value ?? "");
        break;
      case "movement":
        summary = `${component.value > 0 ? "+" : ""}${component.value} · ${component.movementType} · ${component.modifierType}`;
        break;
      case "baseSpeed":
        summary = `${component.movementType} ${component.value}`;
        break;
      default:
        summary = String(component.type ?? "");
    }

    if (!component.duration) return summary;
    const duration = component.duration.unit === "unlimited"
      ? localize("PF2E_CRITICAL_FORGE.Duration.Unlimited")
      : `${component.duration.value} ${localize(`PF2E_CRITICAL_FORGE.Duration.${{
          rounds: "Rounds",
          minutes: "Minutes",
          hours: "Hours",
          days: "Days"
        }[component.duration.unit] ?? "Rounds"}`)}`;
    return `${summary} · ${localize("PF2E_CRITICAL_FORGE.EffectForge.ComponentDurationShort")}: ${duration}`;
  }

  #conditionOptions(selected) {
    const configured = CONFIG.PF2E?.conditionTypes ?? {};
    const entries = Object.entries(configured)
      .filter(([value]) => value !== "persistent-damage" || value === selected)
      .map(([value, label]) => ({
        value,
        label: game.i18n.localize(label),
        isValued: isValuedCondition(value)
      }));

    const source = entries.length > 0
      ? entries
      : FALLBACK_CONDITIONS.map((value) => ({
          value,
          label: value,
          isValued: isValuedCondition(value)
        }));

    if (selected && !source.some((option) => option.value === selected)) {
      source.push({
        value: selected,
        label: selected,
        isValued: isValuedCondition(selected)
      });
    }

    return source
      .map((option) => ({ ...option, selected: option.value === selected }))
      .sort((a, b) => a.label.localeCompare(b.label, game.i18n.lang));
  }

  #syncStateFromForm() {
    const form = this.element;
    if (!(form instanceof HTMLFormElement)) return;

    const data = new FormData(form);
    this.selectedItemId = String(data.get("selectedItemId") ?? this.selectedItemId ?? "").trim();
    this.state.effectId = String(data.get("effectId") ?? "").trim();
    this.state.effectName = String(data.get("effectName") ?? "");
    this.state.description = String(data.get("description") ?? "").slice(0, 1000);
    this.state.img = String(data.get("img") ?? "icons/svg/aura.svg");

    const unlimited = data.get("unlimitedDuration") === "on";
    this.state.durationValue = Number(data.get("durationValue") ?? 0);
    this.state.durationUnit = unlimited
      ? "unlimited"
      : String(data.get("durationUnit") ?? "rounds");
    this.state.durationExpiry = String(data.get("durationExpiry") ?? "turn-end");

    this.state.components = this.state.components.map((component, index) => {
      const prefix = `components.${index}`;
      const uiState = {
        _uiId: component._uiId,
        _collapsed: Boolean(component._collapsed)
      };
      if (component._collapsed) return component;

      const hasDurationOverride = data.get(`${prefix}.durationOverride`) === "on";
      const componentUnlimited = data.get(`${prefix}.unlimitedDuration`) === "on";
      const commonState = { ...uiState };
      if (hasDurationOverride) {
        commonState.duration = componentUnlimited
          ? { value: -1, unit: "unlimited", expiry: null }
          : {
              value: Number(data.get(`${prefix}.durationValue`) ?? 0),
              unit: String(data.get(`${prefix}.durationUnit`) ?? "rounds"),
              expiry: String(data.get(`${prefix}.durationExpiry`) ?? "turn-end")
            };
      }
      if (component.type === "condition") {
        const raw = String(data.get(`${prefix}.value`) ?? "").trim();
        return {
          ...commonState,
          type: "condition",
          slug: String(data.get(`${prefix}.slug`) ?? "").trim(),
          value: raw === "" ? undefined : Number.parseInt(raw, 10)
        };
      }

      if (component.type === "persistentDamage") {
        const rawDc = String(data.get(`${prefix}.dc`) ?? "").trim();
        return {
          ...commonState,
          type: "persistentDamage",
          formula: String(data.get(`${prefix}.formula`) ?? "").trim(),
          damageType: String(data.get(`${prefix}.damageType`) ?? "").trim(),
          dc: rawDc === "" ? undefined : Number(rawDc)
        };
      }

      if (component.type === "resistance") {
        return {
          ...commonState,
          type: "resistance",
          resistanceType: String(data.get(`${prefix}.resistanceType`) ?? "").trim(),
          value: Number(data.get(`${prefix}.value`) ?? 0)
        };
      }

      if (component.type === "weakness") {
        return {
          ...commonState,
          type: "weakness",
          weaknessType: String(data.get(`${prefix}.weaknessType`) ?? "").trim(),
          value: Number(data.get(`${prefix}.value`) ?? 0)
        };
      }

      if (component.type === "immunity") {
        return {
          ...commonState,
          type: "immunity",
          immunityType: String(data.get(`${prefix}.immunityType`) ?? "").trim()
        };
      }

      if (component.type === "fastHealing") {
        return {
          ...commonState,
          type: "fastHealing",
          value: Number(data.get(`${prefix}.value`) ?? 0)
        };
      }

      if (component.type === "regeneration") {
        return {
          ...commonState,
          type: "regeneration",
          value: Number(data.get(`${prefix}.value`) ?? 0),
          deactivatedBy: data.getAll(`${prefix}.deactivatedBy`)
            .map((entry) => String(entry).trim())
            .filter(Boolean)
        };
      }

      if (component.type === "temporaryHitPoints") {
        return {
          ...commonState,
          type: "temporaryHitPoints",
          value: Number(data.get(`${prefix}.value`) ?? 0)
        };
      }

      if (component.type === "movement") {
        return {
          ...commonState,
          type: "movement",
          movementType: String(data.get(`${prefix}.movementType`) ?? "land").trim(),
          value: Number(data.get(`${prefix}.value`) ?? 0),
          modifierType: String(data.get(`${prefix}.modifierType`) ?? "status")
        };
      }

      if (component.type === "baseSpeed") {
        return {
          ...commonState,
          type: "baseSpeed",
          movementType: String(data.get(`${prefix}.movementType`) ?? "fly").trim(),
          value: Number(data.get(`${prefix}.value`) ?? 0)
        };
      }

      const selectorChoice = String(
        data.get(`${prefix}.selectorChoice`) ?? component.selector ?? ""
      ).trim();
      const selector = selectorChoice === this.constructor.#api().selectors.customValue
        ? String(data.get(`${prefix}.customSelector`) ?? "").trim()
        : selectorChoice;

      return {
        ...commonState,
        type: "modifier",
        selector,
        value: Number(data.get(`${prefix}.value`) ?? 0),
        modifierType: String(data.get(`${prefix}.modifierType`) ?? "status")
      };
    });
    this.#refreshDirtyState();
  }

  #buildDefinition({ sync = true } = {}) {
    if (sync) this.#syncStateFromForm();

    const builder = this.constructor.#api().builders
      .effect()
      .setId(this.state.effectId || `pf2e-critical-forge.custom.${foundry.utils.randomID()}`)
      .setName(this.state.effectName)
      .setDescription(
        `<p>${foundry.utils.escapeHTML(this.state.description.trim())}</p>`
      )
      .setImage(this.state.img)
      .setApplication(this.definitionApplication)
      .setMetadata({
        ...this.definitionMetadata,
        originModule: this.definitionMetadata.originModule ?? MODULE_ID,
        originFeature: this.definitionMetadata.originFeature ?? "effect-forge-ui"
      });

    if (this.state.durationUnit === "unlimited") {
      builder.setDuration(-1, "unlimited", null);
    } else {
      builder.setDuration(
        this.state.durationValue,
        this.state.durationUnit,
        this.state.durationExpiry
      );
    }

    for (const stateComponent of this.state.components) {
      const component = stripComponentUiState(stateComponent);
      if (component.type === "condition") {
        builder.addCondition(component.slug, component.value, { duration: component.duration });
      } else if (component.type === "modifier") {
        builder.addModifier(component);
      } else if (component.type === "persistentDamage") {
        builder.addPersistentDamage(component);
      } else if (component.type === "resistance") {
        builder.addResistance(component);
      } else if (component.type === "weakness") {
        builder.addWeakness(component);
      } else if (component.type === "immunity") {
        builder.addImmunity(component);
      } else if (component.type === "fastHealing") {
        builder.addFastHealing(component);
      } else if (component.type === "regeneration") {
        builder.addRegeneration(component);
      } else if (component.type === "temporaryHitPoints") {
        builder.addTemporaryHitPoints(component);
      } else if (component.type === "movement") {
        builder.addMovement(component);
      } else if (component.type === "baseSpeed") {
        builder.addBaseSpeed(component);
      }
    }

    return builder.build();
  }

  #localizeIssue(issue) {
    const text = issue.message
      ?? (issue.messageKey
        ? game.i18n.format(`PF2E_CRITICAL_FORGE.${issue.messageKey}`, issue.data ?? {})
        : issue.data?.message ?? issue.code);

    return {
      ...issue,
      text,
      hasComponent: Number.isInteger(issue.componentIndex),
      componentNumber: Number.isInteger(issue.componentIndex) ? issue.componentIndex + 1 : null
    };
  }

  #setValidationReport(result) {
    const localized = result.issues.map((issue) => this.#localizeIssue(issue));
    const groups = VALIDATION_GROUPS.map(([severity, labelKey, icon]) => {
      const issues = localized.filter((issue) => issue.severity === severity);
      return {
        severity,
        label: game.i18n.localize(labelKey),
        icon,
        count: issues.length,
        issues,
        hasIssues: issues.length > 0
      };
    }).filter((group) => group.hasIssues);

    const errorCount = localized.filter((issue) => issue.severity === "error").length;
    const warningCount = localized.filter((issue) => issue.severity === "warning").length;

    this.validationReport = {
      valid: result.valid,
      issueCount: localized.length,
      errorCount,
      warningCount,
      groups,
      hasIssues: localized.length > 0,
      statusClass: errorCount > 0 ? "invalid" : "valid",
      statusIcon: errorCount > 0 ? "fa-circle-xmark" : "fa-circle-check",
      statusText: game.i18n.localize(
        errorCount > 0
          ? "PF2E_CRITICAL_FORGE.EffectForge.Validation.HasErrors"
          : "PF2E_CRITICAL_FORGE.EffectForge.Validation.NoErrors"
      )
    };
  }

  async #ensurePreviewData() {
    if (this.definitionPreview !== null && this.validationReport !== null) return;

    try {
      const definition = this.#buildDefinition({ sync: false });
      const validation = this.constructor.#api().effects.analyze(definition);
      this.#setValidationReport(validation);
      this.definitionPreview = JSON.stringify(definition, null, 2);

      if (this.compiledPreview === null && validation.valid) {
        const compiled = await this.constructor.#api().effects.toItemSources(definition);
        this.compiledPreview = JSON.stringify(compiled.length === 1 ? compiled[0] : compiled, null, 2);
      }
    } catch (error) {
      console.warn(`${MODULE_ID} | Initial preview could not be prepared`, error);
    }
  }

  #invalidatePreviews() {
    this.validationReport = null;
    this.definitionPreview = null;
    this.compiledPreview = null;
  }

  #localizeTransferError(error) {
    const suffix = TRANSFER_ERROR_KEYS[error?.code] ?? "Unknown";
    return game.i18n.format(
      `PF2E_CRITICAL_FORGE.EffectForge.TransferErrors.${suffix}`,
      error?.data ?? {}
    );
  }

  async #loadImportedData(value) {
    const imported = this.constructor.#api().effects.parseImport(value);
    const validation = this.constructor.#api().effects.analyze(imported.definition);
    if (!validation.valid) {
      const first = validation.errors?.[0];
      throw new EffectTransferError(
        "IMPORT_VALIDATION_FAILED",
        "The imported Effect Definition did not pass validation.",
        { code: first?.code ?? "UNKNOWN", count: validation.errors?.length ?? 0 }
      );
    }

    this.sourceItem = null;
    this.selectedItemId = "";
    this.unmanagedRules = foundry.utils.deepClone(imported.unmanagedRules ?? []);
    this.itemReadWarnings = this.unmanagedRules.length > 0
      ? [{ code: "IMPORT_UNMANAGED_RULES_PRESERVED", count: this.unmanagedRules.length }]
      : [];
    this.migrationReport = foundry.utils.deepClone(imported.migration ?? null);
    this.#setStateFromDefinition(imported.definition);
    this.componentMenuOpen = false;
    this.#setValidationReport(validation);
    this.definitionPreview = JSON.stringify(imported.definition, null, 2);
    this.compiledPreview = null;
    this.#markClean();
    this.preservedScrollState = new Map();
    await this.render({ force: true });

    ui.notifications.info(game.i18n.format(
      "PF2E_CRITICAL_FORGE.EffectForge.ImportSuccess",
      { name: imported.definition.name, count: imported.definition.components.length }
    ));
    return imported;
  }

  #createExportJson() {
    const definition = this.#buildDefinition();
    const validation = this.constructor.#api().effects.analyze(definition);
    if (!validation.valid) {
      const first = validation.errors?.[0];
      this.#setValidationReport(validation);
      this.definitionPreview = JSON.stringify(definition, null, 2);
      this.compiledPreview = null;
      throw new EffectTransferError(
        "EXPORT_VALIDATION_FAILED",
        "The Effect Definition must be valid before it can be exported.",
        { code: first?.code ?? "UNKNOWN", count: validation.errors?.length ?? 0 }
      );
    }

    return {
      definition,
      text: this.constructor.#api().effects.serializeExport(definition, {
        unmanagedRules: this.unmanagedRules
      })
    };
  }

  #showTransferError(error, operation) {
    console.error(`${MODULE_ID} | ${operation} failed`, error);
    const message = error instanceof EffectTransferError
      ? this.#localizeTransferError(error)
      : error.message;
    ui.notifications.error(message);
  }

  static async #loadSelectedItem() {
    this.#syncStateFromForm();
    const item = game.items?.get?.(this.selectedItemId)
      ?? listWorldEffects().find((candidate) => candidate.id === this.selectedItemId);

    if (!item) {
      ui.notifications.warn(
        game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.SelectEffectToLoad")
      );
      return;
    }

    if (!await this.#confirmDiscardChanges()) return;

    try {
      await this.loadItem(item, { render: false });
      this.preservedScrollState = new Map();
      await this.render({ force: true });
      ui.notifications.info(game.i18n.format(
        "PF2E_CRITICAL_FORGE.EffectForge.ItemLoaded",
        { name: item.name }
      ));
    } catch (error) {
      console.error(`${MODULE_ID} | Loading effect Item failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static #importJsonFile() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,application/json";
    input.hidden = true;

    input.addEventListener("change", async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const text = await readEffectImportFile(file);
        if (!await this.#confirmDiscardChanges()) return;
        await this.#loadImportedData(text);
      } catch (error) {
        this.#showTransferError(error, "JSON file import");
      }
    }, { once: true });

    input.click();
  }

  static async #importClipboard() {
    try {
      if (!globalThis.navigator?.clipboard?.readText) {
        throw new EffectTransferError(
          "CLIPBOARD_UNAVAILABLE",
          "Clipboard reading is unavailable."
        );
      }
      const text = await globalThis.navigator.clipboard.readText();
      if (!await this.#confirmDiscardChanges()) return;
      await this.#loadImportedData(text);
    } catch (error) {
      this.#showTransferError(error, "clipboard import");
    }
  }

  static #exportJson() {
    try {
      const { definition, text } = this.#createExportJson();
      downloadEffectExport(text, buildEffectExportFilename(definition));
      ui.notifications.info(game.i18n.format(
        "PF2E_CRITICAL_FORGE.EffectForge.ExportSuccess",
        { name: definition.name }
      ));
    } catch (error) {
      this.#showTransferError(error, "JSON export");
      if (error instanceof EffectTransferError && error.code === "EXPORT_VALIDATION_FAILED") {
        this.#renderPreservingScroll();
      }
    }
  }

  static async #copyExport() {
    try {
      const { text } = this.#createExportJson();
      await this.constructor.#copyText(text);
    } catch (error) {
      this.#showTransferError(error, "export copy");
      if (error instanceof EffectTransferError && error.code === "EXPORT_VALIDATION_FAILED") {
        this.#renderPreservingScroll();
      }
    }
  }

  static async #newEffect() {
    if (!await this.#confirmDiscardChanges()) return;
    this.preservedScrollState = new Map();
    this.resetToNewEffect({ render: true });
  }

  static #toggleComponentMenu() {
    this.#syncStateFromForm();
    this.componentMenuOpen = !this.componentMenuOpen;
    this.#renderPreservingScroll();
  }

  static #addCondition() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({ type: "condition", slug: "frightened", value: 1 }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addModifier() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "modifier",
      selector: "will",
      value: -1,
      modifierType: "circumstance"
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addPersistentDamage() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "persistentDamage",
      formula: "1d6",
      damageType: "bleed",
      dc: undefined
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addResistance() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "resistance",
      resistanceType: "fire",
      value: 5
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addWeakness() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "weakness",
      weaknessType: "fire",
      value: 5
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addImmunity() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "immunity",
      immunityType: "fire"
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addFastHealing() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "fastHealing",
      value: 2
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addRegeneration() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "regeneration",
      value: 5,
      deactivatedBy: ["acid", "fire"]
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addTemporaryHitPoints() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "temporaryHitPoints",
      value: 5
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addMovement() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "movement",
      movementType: "land",
      value: 10,
      modifierType: "status"
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #addBaseSpeed() {
    this.#syncStateFromForm();
    this.state.components.push(attachComponentUiState({
      type: "baseSpeed",
      movementType: "fly",
      value: 30
    }));
    this.componentMenuOpen = false;
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #removeComponent(event, target) {
    this.#syncStateFromForm();
    const index = Number(target.dataset.index);
    if (Number.isInteger(index) && index >= 0 && index < this.state.components.length) {
      this.state.components.splice(index, 1);
    }
    this.#invalidatePreviews();
    this.#markDirty();
    this.#renderPreservingScroll();
  }

  static #duplicateComponent(event, target) {
    this.#syncStateFromForm();
    const index = Number(target.dataset.index);
    if (duplicateComponent(this.state.components, index)) {
      this.#invalidatePreviews();
      this.#markDirty();
      this.#renderPreservingScroll();
    }
  }

  static #moveComponentUp(event, target) {
    this.#syncStateFromForm();
    const index = Number(target.dataset.index);
    if (moveComponent(this.state.components, index, "up")) {
      this.#invalidatePreviews();
      this.#markDirty();
      this.#renderPreservingScroll();
    }
  }

  static #moveComponentDown(event, target) {
    this.#syncStateFromForm();
    const index = Number(target.dataset.index);
    if (moveComponent(this.state.components, index, "down")) {
      this.#invalidatePreviews();
      this.#markDirty();
      this.#renderPreservingScroll();
    }
  }

  static #toggleComponentCollapsed(event, target) {
    this.#syncStateFromForm();
    const index = Number(target.dataset.index);
    if (toggleComponentCollapsed(this.state.components, index)) {
      this.#renderPreservingScroll();
    }
  }

  static #focusComponent(event, target) {
    const index = Number(target.dataset.index);
    const root = this.element;
    if (!(root instanceof HTMLElement) || !Number.isInteger(index)) return;
    const card = root.querySelector(`[data-component-index="${index}"]`);
    if (!(card instanceof HTMLElement)) return;
    const component = this.state.components[index];
    if (component?._collapsed) {
      component._collapsed = false;
      this.#renderPreservingScroll().then(() => {
        const refreshed = this.element?.querySelector?.(`[data-component-index="${index}"]`);
        refreshed?.scrollIntoView?.({ behavior: "smooth", block: "center" });
        refreshed?.classList?.add("validation-focus");
        globalThis.setTimeout(() => refreshed?.classList?.remove("validation-focus"), 1400);
      });
      return;
    }
    card.scrollIntoView({ behavior: "smooth", block: "center" });
    card.classList.add("validation-focus");
    globalThis.setTimeout(() => card.classList.remove("validation-focus"), 1400);
  }

  static async #browseImage() {
    this.#syncStateFromForm();

    const Picker = globalThis.FilePicker
      ?? foundry.applications?.apps?.FilePicker?.implementation;

    if (!Picker) {
      ui.notifications.warn(
        game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.ImagePickerUnavailable")
      );
      return;
    }

    const picker = new Picker({
      type: "image",
      current: this.state.img,
      callback: (path) => {
        this.state.img = path;
        this.#invalidatePreviews();
        this.#markDirty();
        this.#renderPreservingScroll();
      }
    });

    await picker.browse();
  }

  static #validateEffect() {
    try {
      const definition = this.#buildDefinition();
      const result = this.constructor.#api().effects.analyze(definition);
      this.#setValidationReport(result);
      this.definitionPreview = JSON.stringify(definition, null, 2);
      this.compiledPreview = null;
      this.#renderPreservingScroll();
    } catch (error) {
      console.error(`${MODULE_ID} | Validation failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #compileEffect() {
    try {
      const definition = this.#buildDefinition();
      const validation = this.constructor.#api().effects.analyze(definition);
      const sources = await this.constructor.#api().effects.toItemSources(definition);
      const result = sources.length === 1 ? sources[0] : sources;
      this.#setValidationReport(validation);
      this.definitionPreview = JSON.stringify(definition, null, 2);
      this.compiledPreview = JSON.stringify(result, null, 2);
      this.#renderPreservingScroll();
      ui.notifications.info(
        game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.CompileSuccess")
      );
    } catch (error) {
      console.error(`${MODULE_ID} | Compilation failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #createItem() {
    try {
      const definition = this.#buildDefinition();
      const items = await this.constructor.#api().effects.createItems(definition, {
        renderSheet: true,
        unmanagedRules: this.unmanagedRules
      });
      const item = items[0] ?? null;
      if (item) {
        await this.loadItem(item, { render: false });
        await this.#renderPreservingScroll();
        const key = items.length > 1
          ? "PF2E_CRITICAL_FORGE.EffectForge.ItemsCreated"
          : "PF2E_CRITICAL_FORGE.EffectForge.ItemCreated";
        ui.notifications.info(game.i18n.format(key, {
          name: definition.name,
          count: items.length
        }));
      }
    } catch (error) {
      console.error(`${MODULE_ID} | Item creation failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #updateItem() {
    if (!this.sourceItem) {
      ui.notifications.warn(
        game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.NoItemLoaded")
      );
      return;
    }

    try {
      const definition = this.#buildDefinition();
      const updated = await this.constructor.#api().effects.updateItem(
        this.sourceItem,
        definition,
        { unmanagedRules: this.unmanagedRules, render: false }
      );
      this.sourceItem = updated ?? this.sourceItem;
      this.selectedItemId = this.sourceItem.id ?? this.selectedItemId;
      this.#invalidatePreviews();
      this.#markClean();
      await this.#renderPreservingScroll();
      ui.notifications.info(game.i18n.format(
        "PF2E_CRITICAL_FORGE.EffectForge.ItemUpdated",
        { name: this.sourceItem.name }
      ));
    } catch (error) {
      console.error(`${MODULE_ID} | Item update failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #applySelected() {
    const targets = canvas?.tokens?.controlled ?? [];
    if (targets.length === 0) {
      ui.notifications.warn(
        game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.NoSelectedTokens")
      );
      return;
    }

    try {
      const definition = this.#buildDefinition();
      const created = await this.constructor.#api().effects.apply(definition, targets, {
        unmanagedRules: this.unmanagedRules
      });
      ui.notifications.info(game.i18n.format(
        "PF2E_CRITICAL_FORGE.EffectForge.Applied",
        { count: created.length }
      ));
    } catch (error) {
      console.error(`${MODULE_ID} | Effect application failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static async #copyText(text) {
    if (!text) return;

    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
    } else if (game.clipboard?.copyPlainText) {
      game.clipboard.copyPlainText(text);
    } else {
      throw new Error("Clipboard API is unavailable.");
    }

    ui.notifications.info(
      game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.Copied")
    );
  }

  static async #copyDefinition() {
    await this.constructor.#copyText(this.definitionPreview);
  }

  static async #copyCompiled() {
    await this.constructor.#copyText(this.compiledPreview);
  }

  static async #commitExternal() {
    if (!this.externalCommit) return;
    try {
      const definition = this.#buildDefinition();
      const validation = this.constructor.#api().effects.analyze(definition);
      this.#setValidationReport(validation);
      this.definitionPreview = JSON.stringify(definition, null, 2);
      if (!validation.valid) {
        await this.#renderPreservingScroll();
        ui.notifications.warn(game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.ExternalInvalid"));
        return;
      }
      await this.externalCommit(foundry.utils.deepClone(definition));
      this.#markClean();
      ui.notifications.info(game.i18n.localize("PF2E_CRITICAL_FORGE.EffectForge.ExternalCommitted"));
      if (this.externalCloseOnCommit) {
        this.allowCloseWithoutPrompt = true;
        await this.close();
      } else {
        await this.#renderPreservingScroll();
      }
    } catch (error) {
      console.error(`${MODULE_ID} | External Effect Forge commit failed`, error);
      ui.notifications.error(error.message);
    }
  }

  static #closeWindow() {
    this.close();
  }
}
